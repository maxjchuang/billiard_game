# `superpowers`

> TODO: description

## Usage

```
const superpowers = require('superpowers');

// TODO: DEMONSTRATE API
```
